package com.cg.demo.beans;

public class Address {

	private String addressLine;

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	
	
}
