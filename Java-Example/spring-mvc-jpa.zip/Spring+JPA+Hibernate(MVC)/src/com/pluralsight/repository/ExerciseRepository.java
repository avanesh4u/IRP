package com.pluralsight.repository;

import com.pluralsight.model.Exercise;

public interface ExerciseRepository {

	Exercise save (Exercise exercise);
	
}
