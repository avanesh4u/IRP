import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cg.ControllerServlet;
import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;


public class ControllerServletTest {

	@Mock
	private CarDAO daoRef;
	
	private ControllerServlet myServlet; 
	
	@Before
	public void setup(){
//		CarDAO daoRef = new MyCarDAO();
		
		MockitoAnnotations.initMocks(this);
		
		myServlet = new ControllerServlet();
		myServlet.setCarDAO(daoRef);
		
	}
	
	
	@Test
	public void test_viewCars_success() throws ServletException, IOException{
		
		myServlet.init();
	
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
		
		
//		String actionName = request.getParameter(ACTION_KEY);
		
		Mockito.when(request.getParameter("action")).thenReturn("viewCarList");
		
//		List<CarDTO> cars = carDAO.findAll();
		
		List<CarDTO> cars = new ArrayList<CarDTO>();
		cars.add(new CarDTO());
		
		Mockito.when(daoRef.findAll()).thenReturn(cars);
		
		myServlet.processRequest(request, response);

		Mockito.verify(daoRef).findAll();
		
		
	}
	
	
	
}
