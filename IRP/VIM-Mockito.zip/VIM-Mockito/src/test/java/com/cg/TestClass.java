package com.cg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

public class TestClass {
	@Mock
	private CarDAO carDao;
	
	private ControllerServlet myServlet;
	
	@Before
	public void setup(){
		MockitoAnnotations.initMocks(this);
		
		myServlet = new ControllerServlet();
		myServlet.setCarDAO(carDao);
	}
	
	@Test
	public void test_processRequest_success(){
//		SETUP
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
		
		List<CarDTO> cars = new LinkedList<CarDTO>();
		cars.add(new CarDTO());
		
		Mockito.when(request.getParameter("action")).thenReturn("viewCarList");
		Mockito.when(carDao.findAll()).thenReturn(cars);
		
//		EXECUTE
		try {
			myServlet.processRequest(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
//		VERIFY
		Mockito.verify(request).getParameter("action");
		Mockito.verify(carDao).findAll();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
